# Responsive Resume Cv Smith
## [Watch it on youtube]()
### Responsive Resume Cv Smith
Beautiful Responsive resume cv website 📄 using html, css and javascript. Light dark mode 🌗 and PDF export.

Don't forget to join the channel for more videos like this. [Bedimcode](https://www.youtube.com/c/Bedimcode)

![Resume cv](/preview.png)
